#!/usr/bin/env python3
"""Prepare a temporary Amnezia installer copy with non-argv token handling."""
from pathlib import Path
import sys

if len(sys.argv) != 3:
    raise SystemExit("Usage: prepare-local-kit.py SOURCE_INSTALLER OUTPUT_COPY")

source_path, output_path = map(Path, sys.argv[1:])
source = source_path.read_text(encoding="utf-8")
old_token_line = 'TOKEN=""; RU_BLOCK=1; RU_DNS=1; ADGUARD=1; AUTO_REBOOT=1; BOT=1'
new_token_line = 'TOKEN="${VPNKIT_LOCAL_TOKEN:-}"; RU_BLOCK=1; RU_DNS=1; ADGUARD=1; AUTO_REBOOT=1; BOT=1'
old_call = '    /usr/local/sbin/vpn-bot-token "$TOKEN" >/dev/null || die "Telegram не принял токен бота"'
new_call = '''    VPNKIT_LOCAL_TOKEN="$TOKEN" python3 - <<'VPNKIT_TOKEN_PY'
import json, os, secrets, tempfile, urllib.request

token = os.environ["VPNKIT_LOCAL_TOKEN"]
try:
    with urllib.request.urlopen("https://api.telegram.org/bot" + token + "/getMe", timeout=15) as response:
        result = json.load(response)
except Exception:
    raise SystemExit("Не удалось проверить токен в Telegram API; проверьте доступ к Telegram и токен.")
if not result.get("ok"):
    raise SystemExit("Telegram API отклонил токен бота.")

path = "/etc/vpn-bot/config.json"
with open(path, encoding="utf-8") as stream:
    config = json.load(stream)
config["token"] = token
config.setdefault("admins", [])
config.setdefault("setup_code", secrets.token_hex(4))
fd, temporary = tempfile.mkstemp(prefix=".config.json.", dir=os.path.dirname(path))
try:
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(config, stream, indent=2, ensure_ascii=False)
        stream.write("\\n")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
finally:
    if os.path.exists(temporary):
        os.unlink(temporary)
VPNKIT_TOKEN_PY
    systemctl enable vpn-bot.service >/dev/null 2>&1
    systemctl restart vpn-bot.service || die "Не удалось запустить Telegram-бота"'''

if source.count(old_token_line) != 1:
    raise SystemExit("Неожиданная версия install-vpn-kit.sh: строка начальной настройки токена не найдена ровно один раз")
if source.count(old_call) != 1:
    raise SystemExit("Неожиданная версия install-vpn-kit.sh: вызов vpn-bot-token не найден ровно один раз")

patched = source.replace(old_token_line, new_token_line, 1).replace(old_call, new_call, 1)
output_path.parent.mkdir(parents=True, exist_ok=True)
with output_path.open("w", encoding="utf-8", newline="\n") as stream:
    stream.write(patched)
output_path.chmod(0o700)
