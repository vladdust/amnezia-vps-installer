#!/usr/bin/env python3
"""Prepare pinned upstream source snapshots from the ZIP files in this package."""
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile
import zipfile
import os

SOURCES = (
    ("archives/amnezia-server-kit-main.zip", "amnezia-server-kit-main"),
    ("archives/tspublock-master.zip", "tspublock-master"),
)
MAX_ARCHIVE = 50 * 1024 * 1024
MAX_EXPANDED = 100 * 1024 * 1024


def archive_hashes(package):
    sums = package / "SHA256SUMS"
    expected = {}
    for line in sums.read_text(encoding="utf-8").splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2:
            expected[parts[1].lstrip("* ")] = parts[0]
    return expected


def extract(archive, destination, expected_root):
    size = archive.stat().st_size
    if size > MAX_ARCHIVE:
        raise RuntimeError("архив %s превышает 50 МБ" % archive.name)
    destination.mkdir(parents=True, mode=0o700)
    expanded = 0
    written = set()
    with zipfile.ZipFile(archive) as zipped:
        entries = zipped.infolist()
        roots = {PurePosixPath(item.filename).parts[0] for item in entries if PurePosixPath(item.filename).parts}
        if roots != {expected_root}:
            raise RuntimeError("неожиданная структура архива %s" % archive.name)
        for item in entries:
            name = PurePosixPath(item.filename)
            if name.is_absolute() or ".." in name.parts or not name.parts:
                raise RuntimeError("небезопасный путь внутри архива")
            mode = item.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise RuntimeError("исходный архив содержит символическую ссылку")
            if item.is_dir():
                continue
            expanded += item.file_size
            if expanded > MAX_EXPANDED:
                raise RuntimeError("распакованный архив превышает 100 МБ")
            relative = Path(*name.parts[1:])
            if not relative.parts:
                continue
            if relative in written:
                raise RuntimeError("повторяющийся путь внутри архива")
            written.add(relative)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
            with zipped.open(item) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            target.chmod(0o755 if mode & 0o111 else 0o644)
    if not any(destination.iterdir()):
        raise RuntimeError("пустой архив исходников")


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: prepare-vendor.py PACKAGE_DIRECTORY")
    package = Path(sys.argv[1]).resolve()
    expected = archive_hashes(package)
    vendor = package / "vendor"
    if vendor.exists():
        raise RuntimeError("каталог vendor уже существует; отказываюсь перезаписывать файлы")
    with tempfile.TemporaryDirectory(prefix="vendor-snapshots-", dir=str(package)) as temporary:
        staging = Path(temporary)
        staged_vendor = staging / "vendor"
        staged_vendor.mkdir(mode=0o700)
        prepared = []
        for relative, root in SOURCES:
            archive = package / relative
            if not archive.is_file():
                raise RuntimeError("не найден вложенный исходник %s" % relative)
            expected_hash = expected.get(relative)
            if not expected_hash:
                raise RuntimeError("в SHA256SUMS отсутствует архив %s" % relative)
            import hashlib
            digest = hashlib.sha256(archive.read_bytes()).hexdigest()
            if digest != expected_hash:
                raise RuntimeError("SHA256 архива не совпал: %s" % relative)
            extracted = staging / root
            extract(archive, extracted, root)
            prepared.append((root, extracted))
        for root, extracted in prepared:
            shutil.copytree(extracted, staged_vendor / root)
        os.replace(staged_vendor, vendor)
    print("Подготовлены локальные снимки исходников; перед установкой проверятся все SHA256.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("ОШИБКА: %s" % error, file=sys.stderr)
        raise SystemExit(1)
