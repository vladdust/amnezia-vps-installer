#!/usr/bin/env bash
# Local integration for upe4d/tspublock's CyberOK updater.
# Source URLs, set names, chain names, and cache path are taken from the
# bundled update_cyberok.sh and README.md. This wrapper adds validated cache
# fallback and boot-time cache-only application.
set -Eeuo pipefail
export LC_ALL=C

IPSET_NAME="TSPUIPS"
CHAIN_NAME="TSPUBLOCK"
CYBEROK_URL="https://raw.githubusercontent.com/tread-lightly/CyberOK_Skipa_ips/main/lists/skipa_cidr.txt"
CYBEROK_FALLBACK_URL="https://raw.githubusercontent.com/tread-lightly/CyberOK_Skipa_ips/main/lists/skipa_checkpoint.csv"
CYBEROK_FILE="${CYBEROK_CACHE_FILE:-/etc/cyberok_ips.txt}"
ADDED_CYBEROK="${CYBEROK_ADDED_FILE:-/etc/cyberok_added.txt}"

log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
die() { log "ERROR: $*" >&2; exit 1; }

normalize() {
    local source_file=$1 output_file=$2
    python3 - "$source_file" "$output_file" <<'PY'
import ipaddress
import re
import sys

source, output = sys.argv[1:]
networks = set()
pattern = re.compile(r"^([0-9]+(?:\.[0-9]+){3}(?:/[0-9]{1,2})?)(?:\s|,|;|$)")
with open(source, encoding="utf-8", errors="replace") as stream:
    for raw in stream:
        line = raw.split("#", 1)[0].replace("\r", "").strip()
        match = pattern.match(line)
        if not match:
            continue
        try:
            network = ipaddress.ip_network(match.group(1), strict=False)
        except ValueError:
            continue
        if network.version == 4:
            networks.add(network.with_prefixlen)

if len(networks) < 5:
    raise SystemExit("CyberOK list has fewer than 5 valid IPv4 entries")
if len(networks) > 65536:
    raise SystemExit("CyberOK list exceeds the bundled TSPUBLOCK limit of 65536 entries")
with open(output, "w", encoding="ascii") as stream:
    stream.write("".join(item + "\n" for item in sorted(networks, key=lambda x: (int(ipaddress.ip_network(x).network_address), ipaddress.ip_network(x).prefixlen))))
print(len(networks))
PY
}

prepare_list() {
    local output_file=$1 raw_file normalized_file count url
    raw_file=$(mktemp)
    normalized_file=$(mktemp)
    trap 'rm -f "${raw_file:-}" "${normalized_file:-}"' RETURN

    for url in "$CYBEROK_URL" "$CYBEROK_FALLBACK_URL"; do
        if command -v curl >/dev/null 2>&1 && curl -fsSL --connect-timeout 10 --max-time 60 "$url" -o "$raw_file" 2>/dev/null; then
            if count=$(normalize "$raw_file" "$normalized_file" 2>/dev/null); then
                cp "$normalized_file" "$output_file"
                log "Получен свежий CyberOK список: $count сетей ($url)"
                return 0
            fi
            log "Источник вернул некорректный или слишком короткий список: $url"
        else
            log "Источник CyberOK сейчас недоступен: $url"
        fi
    done

    if [ -s "$CYBEROK_FILE" ] && count=$(normalize "$CYBEROK_FILE" "$normalized_file" 2>/dev/null); then
        cp "$normalized_file" "$output_file"
        log "Используется сохранённый CyberOK кэш: $count сетей ($CYBEROK_FILE)"
        return 0
    fi

    die "Нет валидного CyberOK списка и кэша; установка остановлена до изменения firewall"
}

ensure_root() {
    [ "$(id -u)" -eq 0 ] || die "Запустите этот режим от root"
}

apply_list() {
    local normalized_file=$1 existing_file combined_file merged_cache details type_line family_line stage_set cache_dir cache_tmp
    local count entry command_name
    ensure_root
    for command_name in ipset iptables python3 sort awk grep sed mktemp date cat wc tr cp mv mkdir chmod dirname; do
        command -v "$command_name" >/dev/null 2>&1 || die "Не найдена команда: $command_name"
    done

    local work_dir
    work_dir=$(mktemp -d)
    stage_set="TSPUIPS_STAGE_$$"
    trap 'ipset destroy "${stage_set:-}" >/dev/null 2>&1 || true; [ -z "${cache_tmp:-}" ] || rm -f -- "$cache_tmp"; rm -rf "${work_dir:-}"' RETURN
    existing_file="$work_dir/existing.txt"
    combined_file="$work_dir/combined.txt"
    merged_cache="$work_dir/cache.txt"
    : > "$existing_file"

    if details=$(ipset list "$IPSET_NAME" -t 2>/dev/null); then
        type_line=$(printf '%s\n' "$details" | sed -n 's/^Type: //p')
        family_line=$(printf '%s\n' "$details" | sed -n 's/^Header: //p')
        [ "$type_line" = "hash:net" ] || die "Существующий набор $IPSET_NAME не hash:net; оставляю его без изменений"
        [[ "$family_line" == *"family inet"* ]] || die "Существующий набор $IPSET_NAME не IPv4; оставляю его без изменений"
        ipset save "$IPSET_NAME" | awk -v name="$IPSET_NAME" '$1 == "add" && $2 == name {print $3}' > "$existing_file"
    fi

    cat "$existing_file" "$normalized_file" | sort -u > "$combined_file"
    count=$(wc -l < "$combined_file" | tr -d ' ')
    [ "$count" -ge 5 ] || die "После объединения получилось слишком мало записей"
    [ "$count" -le 65536 ] || die "Общий набор превысит лимит 65536 записей; активный набор не менялся"

    # Cache only the project's CyberOK list, preserving its upstream
    # append-only behavior so a temporary upstream outage cannot erase entries.
    if [ -s "$CYBEROK_FILE" ]; then
        if normalize "$CYBEROK_FILE" "$work_dir/old-cache.txt" >/dev/null 2>&1; then
            cat "$work_dir/old-cache.txt" "$normalized_file" | sort -u > "$merged_cache"
        else
            cp "$normalized_file" "$merged_cache"
        fi
    else
        cp "$normalized_file" "$merged_cache"
    fi
    cache_dir=$(dirname "$CYBEROK_FILE")
    mkdir -p "$cache_dir"
    cache_tmp=$(mktemp "$cache_dir/.cyberok_ips.XXXXXX")
    cp "$merged_cache" "$cache_tmp"
    chmod 0644 "$cache_tmp"
    mv -f "$cache_tmp" "$CYBEROK_FILE"
    cache_tmp=""

    # Build a complete replacement set and swap it atomically, preserving any
    # existing members while adding CyberOK entries. The active iptables rule
    # continues to reference the stable TSPUIPS name during the swap.
    ipset create "$stage_set" hash:net family inet maxelem 65536
    while IFS= read -r entry; do
        [ -n "$entry" ] && ipset add "$stage_set" "$entry" -exist
    done < "$combined_file"

    if ipset list "$IPSET_NAME" -t >/dev/null 2>&1; then
        ipset swap "$stage_set" "$IPSET_NAME"
        ipset destroy "$stage_set"
        stage_set=""
    else
        ipset rename "$stage_set" "$IPSET_NAME"
        stage_set=""
    fi

    # Apply the exact TSPUBLOCK policy documented by upe4d/tspublock.
    iptables -N "$CHAIN_NAME" 2>/dev/null || true
    iptables -C INPUT -j "$CHAIN_NAME" 2>/dev/null || iptables -I INPUT 1 -j "$CHAIN_NAME"
    iptables -C "$CHAIN_NAME" -p tcp --tcp-flags RST RST -m set --match-set "$IPSET_NAME" src -j DROP 2>/dev/null \
        || iptables -I "$CHAIN_NAME" 1 -p tcp --tcp-flags RST RST -m set --match-set "$IPSET_NAME" src -j DROP

    mkdir -p "$(dirname "$ADDED_CYBEROK")"
    printf '%s\n' "$(date '+%Y-%m-%d %H:%M:%S') CyberOK apply count=$count" >> "$ADDED_CYBEROK"
    log "Применено $count сетей; создано правило TCP RST в цепочке $CHAIN_NAME"
}

mode=${1:-update}
case "$mode" in
    --prepare)
        [ "$#" -eq 2 ] || die "Использование: $0 --prepare <файл-вывода>"
        prepare_list "$2"
        ;;
    --seed)
        [ "$#" -eq 2 ] && [ -s "$2" ] || die "Использование: $0 --seed <файл-списка>"
        work_dir=$(mktemp -d)
        trap 'rm -rf "${work_dir:-}"' EXIT
        normalize "$2" "$work_dir/normalized.txt" >/dev/null
        apply_list "$work_dir/normalized.txt"
        ;;
    --cache-only)
        [ "$#" -eq 1 ] || die "Использование: $0 --cache-only"
        [ -s "$CYBEROK_FILE" ] || die "Кэш отсутствует: $CYBEROK_FILE"
        work_dir=$(mktemp -d)
        trap 'rm -rf "${work_dir:-}"' EXIT
        normalize "$CYBEROK_FILE" "$work_dir/normalized.txt" >/dev/null
        apply_list "$work_dir/normalized.txt"
        ;;
    update)
        [ "$#" -eq 1 ] || die "Использование: $0"
        work_dir=$(mktemp -d)
        trap 'rm -rf "${work_dir:-}"' EXIT
        prepare_list "$work_dir/fetched.txt"
        apply_list "$work_dir/fetched.txt"
        ;;
    *)
        die "Неизвестный параметр: $mode"
        ;;
esac
