#!/usr/bin/env python3
"""Standalone button-driven Telegram manager for an existing 3x-ui panel."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
import os
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


LOG = logging.getLogger("three_x_ui_bot")
DAY_MS = 24 * 60 * 60 * 1000
TERMS = ((1, "1 день"), (7, "7 дней"), (30, "30 дней"), (90, "90 дней"), (365, "365 дней"))
LINK_PROTOCOLS = {"vmess", "vless", "trojan", "shadowsocks", "hysteria", "mtproto"}


class BotError(Exception):
    pass


def load_config(path: str) -> dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as stream:
            config = json.load(stream)
    except (OSError, ValueError) as exc:
        raise BotError(f"Не удалось прочитать конфигурацию: {exc}") from exc
    required = ("panel_url", "api_token", "telegram_token", "admins")
    if not isinstance(config, dict) or any(not config.get(key) for key in required):
        raise BotError("В конфигурации не заполнены обязательные поля.")
    config["panel_url"] = str(config["panel_url"]).rstrip("/")
    parsed = urllib.parse.urlsplit(config["panel_url"])
    if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.query or parsed.fragment:
        raise BotError("Адрес панели должен быть HTTP(S) URL без логина, пароля, query и fragment.")
    if parsed.username or parsed.password:
        raise BotError("Не помещайте логин и пароль в URL панели.")
    if parsed.scheme != "https" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
        raise BotError("Для удалённой панели требуется HTTPS: API-токен иначе передавался бы открыто.")
    if not isinstance(config["admins"], list):
        raise BotError("admins должен быть списком числовых Telegram ID.")
    try:
        if any(isinstance(value, bool) or not str(value).isdigit() for value in config["admins"]):
            raise ValueError("not a positive integer")
        admins = {int(value) for value in config["admins"]}
    except (TypeError, ValueError) as exc:
        raise BotError("admins должен содержать числовые Telegram ID.") from exc
    if not admins or any(admin <= 0 for admin in admins):
        raise BotError("Добавьте хотя бы один положительный Telegram ID администратора.")
    config["admins"] = admins
    return config


class PanelAPI:
    def __init__(self, base_url: str, token: str):
        self.base = base_url.rstrip("/") + "/panel/api"
        self.token = token
        self.ssl_context = ssl.create_default_context()

    def request(self, path: str, method: str = "GET", body: Any = None) -> Any:
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {"Accept": "application/json", "Authorization": "Bearer " + self.token}
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=25, context=self.ssl_context) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
        except urllib.error.HTTPError as exc:
            detail = exc.read(1200).decode("utf-8", "replace").strip()
            raise BotError(f"3x-ui вернул HTTP {exc.code}: {detail or exc.reason}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            raise BotError(f"Не удалось связаться с панелью 3x-ui: {reason}") from exc
        if len(raw) > 4 * 1024 * 1024:
            raise BotError("Ответ панели превышает допустимый размер 4 МБ.")
        try:
            result = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise BotError("Панель вернула ответ не в JSON. Проверьте адрес панели и API-путь.") from exc
        if isinstance(result, dict) and result.get("success") is False:
            message = result.get("msg") or result.get("message") or "запрос отклонён"
            raise BotError("Ошибка 3x-ui: " + str(message)[:700])
        return result

    def list_clients(self) -> list[dict[str, Any]]:
        response = self.request("/clients/list")
        rows = response.get("obj") if isinstance(response, dict) else None
        return [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []

    def list_inbounds(self) -> list[dict[str, Any]]:
        response = self.request("/inbounds/options")
        rows = response.get("obj") if isinstance(response, dict) else None
        return [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []

    def online_clients(self) -> set[str]:
        response = self.request("/clients/onlines", method="POST", body={})
        rows = response.get("obj") if isinstance(response, dict) else None
        return {str(value) for value in rows} if isinstance(rows, list) else set()

    def get_client(self, email: str) -> dict[str, Any]:
        query = urllib.parse.urlencode({"email": email})
        response = self.request("/clients/get?" + query)
        obj = response.get("obj") if isinstance(response, dict) else None
        if not isinstance(obj, dict):
            raise BotError("Клиент не найден в панели.")
        client = obj.get("client") if isinstance(obj.get("client"), dict) else obj
        merged = dict(client)
        for field in ("inboundIds", "externalLinks", "traffic"):
            if field in obj:
                merged[field] = obj[field]
        return merged

    def client_links(self, email: str) -> list[str]:
        path = "/clients/links/" + urllib.parse.quote(email, safe="")
        response = self.request(path)
        values = response.get("obj") if isinstance(response, dict) else None
        return [str(value) for value in values if isinstance(value, str)] if isinstance(values, list) else []

    def add_client(self, email: str, inbound_id: int, expiry_ms: int) -> None:
        self.request("/clients/add", method="POST", body={
            "client": {
                "email": email,
                "expiryTime": expiry_ms,
                "enable": True,
                "totalGB": 0,
                "limitIp": 0,
                "limitHwid": 0,
                "tgId": 0,
            },
            "inboundIds": [inbound_id],
        })

    def update_client(self, email: str, **fields: Any) -> None:
        query = urllib.parse.urlencode({"email": email})
        body = {"email": email, **fields}
        self.request("/clients/update?" + query, method="POST", body=body)


class TelegramAPI:
    def __init__(self, token: str):
        self.base = "https://api.telegram.org/bot" + token + "/"
        self.ssl_context = ssl.create_default_context()

    def call(self, method: str, payload: dict[str, Any] | None = None, timeout: int = 40) -> Any:
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json"} if data is not None else {}
        request = urllib.request.Request(self.base + method, data=data, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout, context=self.ssl_context) as response:
                result = json.loads(response.read(2 * 1024 * 1024).decode("utf-8"))
        except urllib.error.HTTPError as exc:
            # HTTPError.__str__ includes the request URL, which contains the bot token.
            raise BotError(f"Telegram Bot API вернул HTTP {exc.code}.") from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", "сетевая ошибка")
            raise BotError(f"Ошибка соединения с Telegram Bot API: {reason}") from exc
        except (TimeoutError, OSError, ValueError) as exc:
            raise BotError(f"Ошибка соединения с Telegram Bot API: {type(exc).__name__}") from exc
        if not result.get("ok"):
            raise BotError("Telegram Bot API: " + str(result.get("description", "неизвестная ошибка")))
        return result.get("result")

    def send(self, chat_id: int, text: str, keyboard: list[list[dict[str, str]]] | None = None) -> Any:
        payload: dict[str, Any] = {"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
        if keyboard:
            payload["reply_markup"] = {"inline_keyboard": keyboard}
        return self.call("sendMessage", payload, timeout=25)

    def edit(self, chat_id: int, message_id: int, text: str,
             keyboard: list[list[dict[str, str]]] | None = None) -> Any:
        payload: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id, "text": text,
                                   "disable_web_page_preview": True}
        if keyboard:
            payload["reply_markup"] = {"inline_keyboard": keyboard}
        else:
            payload["reply_markup"] = {"inline_keyboard": []}
        try:
            return self.call("editMessageText", payload, timeout=25)
        except BotError as exc:
            # Telegram rejects editing when the text and keyboard are unchanged.
            if "message is not modified" not in str(exc).lower():
                raise
            return None

    def answer(self, callback_id: str, text: str = "") -> None:
        try:
            self.call("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180]}, timeout=15)
        except BotError:
            LOG.debug("Could not answer callback query")


class Bot:
    def __init__(self, config: dict[str, Any], state_file: str = "/var/lib/3x-ui-telegram-bot/offset"):
        self.admins: set[int] = config["admins"]
        self.panel = PanelAPI(config["panel_url"], config["api_token"])
        self.telegram = TelegramAPI(config["telegram_token"])
        self.state_file = Path(state_file)
        try:
            self.offset = int(self.state_file.read_text(encoding="ascii").strip())
        except FileNotFoundError:
            self.offset = 0
        except (OSError, ValueError) as exc:
            raise BotError(f"Не удалось прочитать состояние Telegram polling: {exc}") from exc
        self.sequence = 0
        self.actions: dict[str, tuple[int, int, tuple[Any, ...], float]] = {}
        self.flows: dict[int, dict[str, Any]] = {}

    def button(self, label: str, user_id: int, chat_id: int, *action: Any) -> dict[str, str]:
        self.sequence += 1
        key = str(self.sequence)
        self.actions[key] = (user_id, chat_id, action, time.monotonic())
        return {"text": label[:60], "callback_data": key}

    def make_keyboard(self, rows: list[list[tuple[int, int, str, tuple[Any, ...]]]]) -> list[list[dict[str, str]]]:
        return [[self.button(label, user, chat, *action) for user, chat, label, action in row] for row in rows]

    def render(self, user_id: int, chat_id: int, text: str,
               rows: list[list[tuple[str, tuple[Any, ...]]]], message_id: int | None = None) -> None:
        encoded = [[(user_id, chat_id, label, action) for label, action in row] for row in rows]
        keyboard = self.make_keyboard(encoded) if rows else None
        if message_id is None:
            self.telegram.send(chat_id, text[:4000], keyboard)
        else:
            self.telegram.edit(chat_id, message_id, text[:4000], keyboard)

    def menu(self, user_id: int, chat_id: int, message_id: int | None = None) -> None:
        self.flows.pop(chat_id, None)
        rows = [
            [("👥 Клиенты", ("clients", 0)), ("➕ Новый клиент", ("new",))],
            [("🔍 Поиск", ("search",)), ("ℹ️ Состояние панели", ("panel",))],
        ]
        self.render(user_id, chat_id, "Управление клиентами 3x-ui", rows, message_id)

    @staticmethod
    def money(value: Any) -> str:
        try:
            number = int(value or 0)
        except (TypeError, ValueError):
            number = 0
        units = ("Б", "КБ", "МБ", "ГБ", "ТБ")
        amount = float(number)
        index = 0
        while amount >= 1024 and index < len(units) - 1:
            amount /= 1024
            index += 1
        return f"{amount:.1f} {units[index]}"

    @staticmethod
    def expiry_text(value: Any) -> str:
        try:
            expiry = int(value or 0)
        except (TypeError, ValueError):
            expiry = 0
        if expiry == 0:
            return "без ограничения"
        if expiry < 0:
            return "срок после первого подключения"
        try:
            return dt.datetime.fromtimestamp(expiry / 1000, tz=dt.timezone.utc).strftime("%d.%m.%Y %H:%M UTC")
        except (OverflowError, OSError, ValueError):
            return "неизвестно"

    def inbound_names(self, ids: Any) -> str:
        if not isinstance(ids, list) or not ids:
            return "не указаны"
        names: dict[int, str] = {}
        try:
            for inbound in self.panel.list_inbounds():
                names[int(inbound.get("id"))] = str(inbound.get("remark") or inbound.get("tag") or inbound.get("id"))
        except (BotError, TypeError, ValueError):
            pass
        return ", ".join(names.get(int(value), f"ID {value}") for value in ids if str(value).lstrip("-").isdigit())

    def client_rows(self, user_id: int, chat_id: int, clients: list[dict[str, Any]], page: int,
                    online: set[str] | None = None, search: str | None = None) -> tuple[str, list[list[tuple[str, tuple[Any, ...]]]]]:
        online = online or set()
        filtered = [row for row in clients if isinstance(row.get("email"), str)]
        if search:
            lowered = search.casefold()
            filtered = [row for row in filtered if lowered in row.get("email", "").casefold()]
        page_size = 8
        page = max(0, min(page, max(0, (len(filtered) - 1) // page_size)))
        shown = filtered[page * page_size:(page + 1) * page_size]
        text = f"Клиенты: {len(filtered)}"
        if search:
            text += f"\nПоиск: {search}"
        if online:
            text += f"\nСейчас онлайн: {len(online)}"
        if not shown:
            text += "\nСовпадений нет."
        rows: list[list[tuple[str, tuple[Any, ...]]]] = []
        for client in shown:
            email = client["email"]
            status = "🟢" if email in online else ("⚪" if client.get("enable", True) else "⏸")
            rows.append([(f"{status} {email[:48]}", ("detail", email))])
        nav: list[tuple[str, tuple[Any, ...]]] = []
        if page > 0:
            nav.append(("⬅️", ("clients", page - 1)))
        if (page + 1) * page_size < len(filtered):
            nav.append(("➡️", ("clients", page + 1)))
        if nav:
            rows.append(nav)
        rows.append([("🔍 Поиск", ("search",)), ("🏠 Меню", ("menu",))])
        return text, rows

    def show_clients(self, user_id: int, chat_id: int, page: int, message_id: int | None = None,
                     search: str | None = None) -> None:
        clients = self.panel.list_clients()
        try:
            online = self.panel.online_clients()
        except BotError as exc:
            LOG.warning("Online status query failed: %s", exc)
            online = set()
        text, rows = self.client_rows(user_id, chat_id, clients, page, online, search)
        self.render(user_id, chat_id, text, rows, message_id)

    def show_detail(self, user_id: int, chat_id: int, email: str, message_id: int | None = None) -> None:
        client = self.panel.get_client(email)
        try:
            row = next((candidate for candidate in self.panel.list_clients()
                        if candidate.get("email") == email), {})
        except BotError:
            row = {}
        data = {**row, **client}
        try:
            online = email in self.panel.online_clients()
        except BotError as exc:
            LOG.warning("Online status query failed: %s", exc)
            online = False
        enabled = bool(data.get("enable", True))
        traffic = data.get("traffic") if isinstance(data.get("traffic"), dict) else {}
        up = traffic.get("up", 0)
        down = traffic.get("down", 0)
        total = data.get("totalGB", 0)
        try:
            quota = "без лимита" if not int(total or 0) else self.money(total)
        except (TypeError, ValueError):
            quota = "неизвестно"
        lines = [
            f"Клиент: {email}",
            f"Состояние: {'онлайн' if online else ('включён' if enabled else 'отключён')}",
            f"Срок: {self.expiry_text(data.get('expiryTime'))}",
            f"Трафик: ↓ {self.money(down)} / ↑ {self.money(up)} (лимит: {quota})",
            "Входящие: " + self.inbound_names(data.get("inboundIds")),
        ]
        status_label = "⏸ Отключить" if enabled else "▶️ Включить"
        rows = [
            [("🔗 Получить конфиг", ("links", email)), ("⏳ Срок доступа", ("expiry", email))],
            [(status_label, ("toggle", email, not enabled))],
            [("⬅️ Клиенты", ("clients", 0)), ("🏠 Меню", ("menu",))],
        ]
        self.render(user_id, chat_id, "\n".join(lines), rows, message_id)

    def show_expiry_choices(self, user_id: int, chat_id: int, email: str,
                            message_id: int | None = None) -> None:
        rows: list[list[tuple[str, tuple[Any, ...]]]] = []
        rows.append([(label, ("set_expiry", email, days)) for days, label in TERMS])
        rows.append([("♾ Без срока", ("confirm_forever", email))])
        rows.append([("⬅️ Карточка", ("detail", email))])
        self.render(user_id, chat_id, f"Добавить срок клиенту {email} или убрать ограничение:", rows, message_id)

    def show_new_terms(self, user_id: int, chat_id: int, message_id: int | None = None) -> None:
        flow = self.flows.get(chat_id, {})
        draft = flow.get("draft", {})
        email = draft.get("email", "")
        inbound_id = draft.get("inbound_id")
        rows = [[(label, ("create", email, inbound_id, days)) for days, label in TERMS]]
        rows.append([("♾ Без срока", ("create", email, inbound_id, 0))])
        rows.append([("❌ Отмена", ("menu",))])
        self.render(user_id, chat_id, f"Выберите срок для нового клиента «{email}»:", rows, message_id)

    def handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = callback.get("id", "")
        actor = callback.get("from", {}).get("id")
        message = callback.get("message") or {}
        chat = message.get("chat") or {}
        chat_id, message_id = chat.get("id"), message.get("message_id")
        if actor not in self.admins or chat.get("type") != "private":
            self.telegram.answer(callback_id, "Действие доступно только администраторам в личном чате.")
            return
        stored = self.actions.get(str(callback.get("data", "")))
        if not stored:
            self.telegram.answer(callback_id, "Кнопка устарела. Откройте меню заново.")
            return
        expected_user, expected_chat, action, _created = stored
        if actor != expected_user or chat_id != expected_chat:
            self.telegram.answer(callback_id, "Эта кнопка создана в другом чате.")
            return
        self.telegram.answer(callback_id)
        try:
            self.dispatch(actor, chat_id, message_id, action)
        except BotError as exc:
            LOG.warning("Action failed for Telegram user %s: %s", actor, exc)
            self.render(actor, chat_id, "Ошибка: " + str(exc)[:700], [[("🏠 Меню", ("menu",))]], message_id)
        except Exception:
            LOG.exception("Unexpected callback failure")
            self.render(actor, chat_id, "Не удалось выполнить действие. Подробности записаны в системный журнал.",
                        [[("🏠 Меню", ("menu",))]], message_id)

    def dispatch(self, user_id: int, chat_id: int, message_id: int, action: tuple[Any, ...]) -> None:
        name, *args = action
        if name == "menu":
            self.menu(user_id, chat_id, message_id)
        elif name == "clients":
            self.show_clients(user_id, chat_id, int(args[0]), message_id)
        elif name == "search":
            self.flows[chat_id] = {"type": "search"}
            self.render(user_id, chat_id, "Отправьте часть имени клиента для поиска.",
                        [[("❌ Отмена", ("menu",))]], message_id)
        elif name == "new":
            inbounds = [item for item in self.panel.list_inbounds()
                        if str(item.get("protocol", "")).lower() in LINK_PROTOCOLS]
            if not inbounds:
                raise BotError("Нет входящих подключений, для которых 3x-ui формирует текстовую ссылку. Поддерживаются VMess, VLESS, Trojan, Shadowsocks, Hysteria и MTProto.")
            rows = []
            for inbound in inbounds:
                label = f"{inbound.get('remark') or inbound.get('tag') or 'Без названия'} · {inbound.get('protocol', '?')}:{inbound.get('port', '?')}"
                rows.append([(label[:58], ("choose_inbound", int(inbound["id"])))])
            rows.append([("❌ Отмена", ("menu",))])
            self.render(user_id, chat_id, "Выберите входящее подключение для нового клиента:", rows, message_id)
        elif name == "choose_inbound":
            self.flows[chat_id] = {"type": "new_name", "inbound_id": int(args[0])}
            self.render(user_id, chat_id, "Отправьте имя нового клиента. Используйте уникальное имя до 64 символов; слеши нельзя.",
                        [[("❌ Отмена", ("menu",))]], message_id)
        elif name == "create":
            email, inbound_id, days = str(args[0]), int(args[1]), int(args[2])
            expiry_ms = 0 if days == 0 else int(time.time() * 1000) + days * DAY_MS
            self.panel.add_client(email, inbound_id, expiry_ms)
            self.flows.pop(chat_id, None)
            lines = [f"Клиент «{email}» создан.", f"Срок: {self.expiry_text(expiry_ms)}"]
            try:
                links = self.panel.client_links(email)
                lines.extend(["", *links] if links else ["", "Для этого типа подключения панель не выдала текстовую ссылку."])
            except BotError as exc:
                lines.extend(["", "Клиент создан, но получить ссылку не удалось: " + str(exc)[:400]])
            self.render(user_id, chat_id, "\n".join(lines), [[("👥 Клиенты", ("clients", 0)), ("🏠 Меню", ("menu",))]], message_id)
        elif name == "detail":
            self.show_detail(user_id, chat_id, str(args[0]), message_id)
        elif name == "links":
            email = str(args[0])
            links = self.panel.client_links(email)
            if not links:
                self.telegram.send(chat_id, "Панель не вернула текстовую ссылку для этого протокола.")
            else:
                self.telegram.send(chat_id, "Ссылки клиента «" + email + "»:\n\n" + "\n".join(links))
            self.show_detail(user_id, chat_id, email, message_id)
        elif name == "expiry":
            self.show_expiry_choices(user_id, chat_id, str(args[0]), message_id)
        elif name == "set_expiry":
            email, days = str(args[0]), int(args[1])
            current = self.panel.get_client(email)
            now = int(time.time() * 1000)
            old_expiry = int(current.get("expiryTime") or 0)
            base = old_expiry if old_expiry > now else now
            new_expiry = base + days * DAY_MS
            self.panel.update_client(email, expiryTime=new_expiry)
            self.show_detail(user_id, chat_id, email, message_id)
        elif name == "confirm_forever":
            email = str(args[0])
            rows = [[("Да, убрать срок", ("set_forever", email)), ("Отмена", ("detail", email))]]
            self.render(user_id, chat_id, f"Убрать ограничение срока у клиента «{email}»?", rows, message_id)
        elif name == "set_forever":
            email = str(args[0])
            self.panel.update_client(email, expiryTime=0)
            self.show_detail(user_id, chat_id, email, message_id)
        elif name == "toggle":
            email, enabled = str(args[0]), bool(args[1])
            self.panel.update_client(email, enable=enabled)
            self.show_detail(user_id, chat_id, email, message_id)
        elif name == "panel":
            inbounds = self.panel.list_inbounds()
            clients = self.panel.list_clients()
            try:
                online = self.panel.online_clients()
            except BotError:
                online = set()
            text = f"Панель 3x-ui доступна.\nВходящих: {len(inbounds)}\nКлиентов: {len(clients)}\nСейчас онлайн: {len(online)}"
            self.render(user_id, chat_id, text, [[("🔄 Обновить", ("panel",)), ("🏠 Меню", ("menu",))]], message_id)
        else:
            raise BotError("Неизвестное действие.")

    def handle_message(self, message: dict[str, Any]) -> None:
        sender = message.get("from") or {}
        chat = message.get("chat") or {}
        user_id, chat_id = sender.get("id"), chat.get("id")
        if user_id not in self.admins or chat.get("type") != "private":
            return
        text = str(message.get("text") or "").strip()
        if text in ("/start", "/start@" + str(sender.get("username", "")), "/menu"):
            self.menu(user_id, chat_id)
            return
        flow = self.flows.get(chat_id)
        if not flow:
            self.menu(user_id, chat_id)
            return
        if flow.get("type") == "search":
            self.flows.pop(chat_id, None)
            if not text or len(text) > 80:
                self.telegram.send(chat_id, "Введите от 1 до 80 символов.")
                return
            try:
                self.show_clients(user_id, chat_id, 0, search=text)
            except BotError as exc:
                self.telegram.send(chat_id, "Ошибка поиска: " + str(exc)[:700])
        elif flow.get("type") == "new_name":
            if (not text or len(text) > 64 or text in (".", "..") or
                    any(ord(char) < 32 or char in "/\\" for char in text)):
                self.telegram.send(chat_id, "Имя должно занимать 1–64 символа, без слешей. Попробуйте снова.")
                return
            flow["type"] = "new_term"
            flow["draft"] = {"email": text, "inbound_id": flow["inbound_id"]}
            self.show_new_terms(user_id, chat_id)

    def run(self) -> None:
        me = self.telegram.call("getMe", timeout=20)
        LOG.info("Started as @%s; allowed admins: %s", me.get("username", "unknown"), sorted(self.admins))
        while True:
            try:
                updates = self.telegram.call("getUpdates", {
                    "offset": self.offset, "timeout": 30,
                    "allowed_updates": ["message", "callback_query"],
                }, timeout=40)
                for update in updates or []:
                    previous_offset = self.offset
                    self.offset = max(self.offset, int(update.get("update_id", 0)) + 1)
                    try:
                        self.save_offset()
                    except BotError:
                        self.offset = previous_offset
                        raise
                    if "callback_query" in update:
                        self.handle_callback(update["callback_query"])
                    elif "message" in update:
                        try:
                            self.handle_message(update["message"])
                        except BotError as exc:
                            user = (update["message"].get("from") or {}).get("id")
                            chat = (update["message"].get("chat") or {}).get("id")
                            if user in self.admins and chat:
                                self.telegram.send(chat, "Ошибка: " + str(exc)[:700])
                now = time.monotonic()
                if len(self.actions) > 1000 or any(now - entry[3] > 3600 for entry in self.actions.values()):
                    self.actions = {key: value for key, value in self.actions.items() if now - value[3] < 3600}
            except BotError as exc:
                LOG.warning("Polling failed: %s", exc)
                time.sleep(3)
            except KeyboardInterrupt:
                return

    def save_offset(self) -> None:
        temporary = self.state_file.with_name(self.state_file.name + ".tmp")
        try:
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            with temporary.open("w", encoding="ascii") as stream:
                stream.write(str(self.offset) + "\n")
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.state_file)
        except OSError as exc:
            raise BotError(f"Не удалось сохранить состояние Telegram polling: {exc}") from exc


def check_panel(config: dict[str, Any]) -> None:
    panel = PanelAPI(config["panel_url"], config["api_token"])
    inbounds = panel.list_inbounds()
    clients = panel.list_clients()
    me = TelegramAPI(config["telegram_token"]).call("getMe", timeout=20)
    print(f"API панели доступен. Входящих: {len(inbounds)}, клиентов: {len(clients)}.")
    print(f"Токен Telegram подтверждён: @{me.get('username', 'unknown')}.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="/etc/3x-ui-telegram-bot/config.json")
    parser.add_argument("--check", action="store_true", help="проверить доступ к API без запуска polling")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        config = load_config(args.config)
        if args.check:
            check_panel(config)
        else:
            Bot(config).run()
    except BotError as exc:
        print("ОШИБКА: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
