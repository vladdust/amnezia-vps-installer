#!/usr/bin/env bash
set -Eeuo pipefail
set +x
umask 077

SOURCE_DIR="${1:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
SERVICE="3x-ui-telegram-bot"
SERVICE_USER="3x-ui-telegram-bot"
INSTALL_DIR="/opt/3x-ui-telegram-bot"
CONFIG_DIR="/etc/3x-ui-telegram-bot"
CONFIG="$CONFIG_DIR/config.json"
CONFIG_TMP=""

die() { printf 'ОШИБКА: %s\n' "$*" >&2; exit 1; }
cleanup() { [ -z "$CONFIG_TMP" ] || rm -f -- "$CONFIG_TMP"; }
trap cleanup EXIT

[ "$(id -u)" -eq 0 ] || die "Запустите установщик через sudo."
[ -r /dev/tty ] || die "Нужен интерактивный терминал для ввода URL панели и токенов."
exec 3</dev/tty
command -v python3 >/dev/null 2>&1 || die "Нужен Python 3."
command -v systemctl >/dev/null 2>&1 || die "На сервере не найден systemd."
[ -f "$SOURCE_DIR/bot.py" ] || die "В пакете не найден bot.py."

if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
    useradd --system --user-group --home-dir /var/lib/3x-ui-telegram-bot --create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
[ ! -L "$CONFIG" ] || die "Конфигурация не должна быть символической ссылкой."
install -d -o root -g "$SERVICE_USER" -m 0750 "$CONFIG_DIR"

RECONFIGURE=0
if [ -f "$CONFIG" ]; then
    read -r -u 3 -p "Сохранить текущие настройки панели и токенов? [Y/n] " KEEP_CONFIG
    KEEP_CONFIG="${KEEP_CONFIG:-Y}"
    case "$KEEP_CONFIG" in
        [Yy]|[Yy][Ee][Ss]) ;;
        [Nn]|[Nn][Oo]) RECONFIGURE=1 ;;
        *) die "Введите Y или n." ;;
    esac
fi

if [ ! -f "$CONFIG" ] || [ "$RECONFIGURE" -eq 1 ]; then
    printf '%s\n' "Понадобится URL уже установленной панели, её API-токен и токен отдельного Telegram-бота."
    printf '%s\n' "API-токен 3x-ui находится в Settings → Security → API Token."
    read -r -u 3 -p "URL панели с web-путём при наличии, без /panel/api (например https://panel.example:2053): " PANEL_URL
    read -r -s -u 3 -p "API-токен 3x-ui: " API_TOKEN
    printf '\n'
    read -r -s -u 3 -p "Токен отдельного Telegram-бота от BotFather: " TELEGRAM_TOKEN
    printf '\n'
    read -r -u 3 -p "Telegram ID администратора (можно несколько через запятую): " ADMIN_INPUT
    [ -n "$PANEL_URL" ] || die "URL панели не может быть пустым."
    [ -n "$API_TOKEN" ] || die "API-токен не может быть пустым."
    [ -n "$TELEGRAM_TOKEN" ] || die "Токен Telegram-бота не может быть пустым."
    ADMIN_JSON=$(python3 -c 'import json,re,sys; values=re.findall(r"[0-9]+", sys.argv[1]); rest=re.sub(r"[0-9]+|[ ,]+", "", sys.argv[1]); sys.exit("Некорректные Telegram ID") if not values or rest else print(json.dumps(sorted(set(map(int, values)))))' "$ADMIN_INPUT") || die "Некорректный список Telegram ID."

    CONFIG_TMP=$(mktemp "$CONFIG_DIR/.config.XXXXXX")
    printf '%s\n' "$PANEL_URL" "$API_TOKEN" "$TELEGRAM_TOKEN" "$ADMIN_JSON" | python3 -c '
import json,sys
target=sys.argv[1]
lines=sys.stdin.read().splitlines()
if len(lines) != 4: raise SystemExit("Некорректные настройки")
url, api_token, telegram_token = lines[:3]
admins=json.loads(lines[3])
with open(target,"w",encoding="utf-8") as stream:
    json.dump({"panel_url":url,"api_token":api_token,"telegram_token":telegram_token,"admins":admins},stream,ensure_ascii=False,indent=2)
    stream.write("\n")
' "$CONFIG_TMP" || die "Не удалось записать конфигурацию."
    install -o root -g "$SERVICE_USER" -m 0640 "$CONFIG_TMP" "$CONFIG"
    rm -f -- "$CONFIG_TMP"
    CONFIG_TMP=""
    unset API_TOKEN TELEGRAM_TOKEN ADMIN_INPUT ADMIN_JSON
fi

install -d -o root -g root -m 0755 "$INSTALL_DIR"
install -o root -g root -m 0755 "$SOURCE_DIR/bot.py" "$INSTALL_DIR/bot.py.new"
mv -f -- "$INSTALL_DIR/bot.py.new" "$INSTALL_DIR/bot.py"
chown root:"$SERVICE_USER" "$CONFIG"
chmod 0640 "$CONFIG"

printf '%s\n' "Проверяю доступ к API панели и Telegram…"
python3 "$INSTALL_DIR/bot.py" --config "$CONFIG" --check || die "Проверка не прошла. Служба не перезапущена; проверьте URL, API-токен и подключение."

cat >"/etc/systemd/system/$SERVICE.service" <<'UNIT'
[Unit]
Description=3x-ui Telegram client manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=3x-ui-telegram-bot
Group=3x-ui-telegram-bot
ExecStart=/usr/bin/python3 /opt/3x-ui-telegram-bot/bot.py --config /etc/3x-ui-telegram-bot/config.json
Restart=on-failure
RestartSec=5
Environment=PYTHONUNBUFFERED=1
StateDirectory=3x-ui-telegram-bot
StateDirectoryMode=0700
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
MemoryDenyWriteExecute=true
UMask=0077

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "$SERVICE"
systemctl restart "$SERVICE"
printf '\nГотово. Отправьте /start своему Telegram-боту, затем управляйте панелью кнопками.\n'
printf 'Статус: systemctl status %s\n' "$SERVICE"
printf 'Журнал: journalctl -u %s -f\n' "$SERVICE"
