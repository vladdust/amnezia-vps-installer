#!/usr/bin/env bash
set -Eeuo pipefail
set +x

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
KIT_DIR="$SCRIPT_DIR/vendor/amnezia-server-kit-main"
TSPU_DIR="$SCRIPT_DIR/vendor/tspublock-master"
KIT_INSTALLER="$KIT_DIR/install-vpn-kit.sh"
TSPU_UPDATER="$SCRIPT_DIR/tspublock-cyberok-update.sh"
MODULE_DIR="$SCRIPT_DIR/modules"
WORK_DIR=""
PATCHED_KIT=""
BOT_TOKEN="${VPN_BOT_TOKEN:-}"

usage() {
    cat <<'EOF'
Установка из локально скопированного пакета:
  sudo bash ./install-local.sh

Скрипт попросит токен Telegram-бота без отображения ввода. Можно заранее
передать его через переменную окружения VPN_BOT_TOKEN.

Требуется установленный и работающий AmneziaWG от AmneziaVPN.
EOF
}

die() { printf 'ОШИБКА: %s\n' "$*" >&2; exit 1; }
say() { printf '\n==> %s\n' "$*"; }

cleanup() {
    unset BOT_TOKEN VPNKIT_LOCAL_TOKEN 2>/dev/null || true
    [ -z "$PATCHED_KIT" ] || rm -f -- "$PATCHED_KIT"
    [ -z "$WORK_DIR" ] || rm -rf -- "$WORK_DIR"
}
trap cleanup EXIT

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then
    usage
    exit 0
fi
[ "$#" -eq 0 ] || die "Неизвестные аргументы. См. --help."
[ "$(id -u)" -eq 0 ] || die "Запустите от root: sudo bash ./install-local.sh"

[ -f "$KIT_INSTALLER" ] || die "В пакете нет исходника Amnezia Server Kit: $KIT_INSTALLER"
[ -f "$TSPU_DIR/update_cyberok.sh" ] || die "В пакете нет исходника CyberOK updater проекта tspublock"
[ -f "$TSPU_UPDATER" ] || die "Не найден локальный установщик CyberOK"
[ -f "$SCRIPT_DIR/SHA256SUMS" ] || die "Нет контрольных сумм исходных архивов"

say "Проверка контрольных сумм вложенных архивов и исходников"
(cd "$SCRIPT_DIR" && sha256sum -c SHA256SUMS) || die "Исходники пакета изменены или повреждены"

[ -r /etc/os-release ] || die "Не найдено описание ОС /etc/os-release"
# shellcheck disable=SC1091
. /etc/os-release
case "${ID:-}" in
    ubuntu)
        version=${VERSION_ID%%.*}
        [ "${version:-0}" -ge 22 ] || die "Нужна Ubuntu 22.04 или новее"
        ;;
    debian)
        version=${VERSION_ID%%.*}
        [ "${version:-0}" -ge 12 ] || die "Нужен Debian 12 или новее"
        ;;
    *) die "Поддерживаются Ubuntu 22.04+ и Debian 12+; обнаружено: ${PRETTY_NAME:-неизвестно}" ;;
esac

for cmd in apt-get docker ip awk grep head dirname sha256sum python3 curl systemctl; do
    command -v "$cmd" >/dev/null 2>&1 || die "Не найдена команда $cmd"
done

say "Проверка уже установленного AmneziaWG"
AWG_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E '^amnezia-awg' | head -n1 || true)
[ -n "$AWG_CONTAINER" ] || die "Не найден работающий контейнер amnezia-awg*. Сначала установите AmneziaWG через приложение AmneziaVPN."
AWG_CONF=$(docker exec "$AWG_CONTAINER" sh -c 'ls /opt/amnezia/awg/*.conf 2>/dev/null' | head -n1 || true)
[ -n "$AWG_CONF" ] || die "В $AWG_CONTAINER не найден конфиг /opt/amnezia/awg/*.conf"
DNS_SUBNET=$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}}{{end}}' amnezia-dns-net 2>/dev/null || true)
[ "$DNS_SUBNET" = "172.29.172.0/24" ] || die "Не найдена стандартная Docker-сеть Amnezia amnezia-dns-net (172.29.172.0/24)"
WAN=$(ip -4 route show default | awk '{print $5; exit}')
[ -n "$WAN" ] || die "Не найден внешний сетевой интерфейс"
printf 'Контейнер: %s\nКонфиг: %s\nСеть: %s\nИнтерфейс VPS: %s\n' "$AWG_CONTAINER" "$AWG_CONF" "$DNS_SUBNET" "$WAN"

WORK_DIR=$(mktemp -d /tmp/amnezia-vps-kit.XXXXXX)
chmod 0700 "$WORK_DIR"

say "Подготовка CyberOK списка до изменений firewall"
"$TSPU_UPDATER" --prepare "$WORK_DIR/cyberok-seed.txt"

if [ -z "$BOT_TOKEN" ]; then
    [ -r /dev/tty ] || die "Нужен токен Telegram-бота. Запустите скрипт в терминале или задайте VPN_BOT_TOKEN."
    read -r -s -p "Введите токен Telegram-бота: " BOT_TOKEN </dev/tty
    printf '\n' >/dev/tty
fi
[[ "$BOT_TOKEN" =~ ^[0-9]+:[A-Za-z0-9_-]+$ ]] || die "Формат токена Telegram-бота выглядит неверно"

say "Подготовка локального установщика Amnezia Server Kit"
PATCHED_KIT="$WORK_DIR/install-vpn-kit.local.sh"
python3 "$SCRIPT_DIR/prepare-local-kit.py" "$KIT_INSTALLER" "$PATCHED_KIT"

say "Запуск официального Amnezia Server Kit из локальной копии"
VPNKIT_LOCAL_TOKEN="$BOT_TOKEN" bash "$PATCHED_KIT"
unset BOT_TOKEN VPNKIT_LOCAL_TOKEN

say "Установка локального CyberOK updater и systemd служб"
install -o root -g root -m 0750 "$TSPU_UPDATER" /usr/local/sbin/tspublock-cyberok-update
install -o root -g root -m 0644 "$SCRIPT_DIR/systemd/tspublock-cyberok.service" /etc/systemd/system/tspublock-cyberok.service
install -o root -g root -m 0644 "$SCRIPT_DIR/systemd/tspublock-cyberok-update.service" /etc/systemd/system/tspublock-cyberok-update.service
install -o root -g root -m 0644 "$SCRIPT_DIR/systemd/tspublock-cyberok.timer" /etc/systemd/system/tspublock-cyberok.timer
systemctl daemon-reload
/usr/local/sbin/tspublock-cyberok-update --seed "$WORK_DIR/cyberok-seed.txt"
systemctl enable --now tspublock-cyberok.service
systemctl enable --now tspublock-cyberok.timer

say "Установка менеджера модулей и функций Telegram-бота"
[ -f "$MODULE_DIR/vpn-bot-module" ] || die "В пакете отсутствует менеджер модулей"
[ -f "$MODULE_DIR/patch-bot-loader.py" ] || die "В пакете отсутствует загрузчик модулей бота"
[ -f "$MODULE_DIR/catalog/client-lifecycle/manifest.json" ] || die "В пакете отсутствует модуль управления доступом"
[ -f "$MODULE_DIR/catalog/as-network-guard/manifest.json" ] || die "В пакете отсутствует модуль сетевой фильтрации"
[ -f "$MODULE_DIR/catalog/admin-management/manifest.json" ] || die "В пакете отсутствует модуль управления администраторами"
install -o root -g root -m 0750 "$MODULE_DIR/vpn-bot-module" /usr/local/sbin/vpn-bot-module
install -d -o root -g root -m 0750 /opt/vpn-bot/module-catalog
cp -a "$MODULE_DIR/catalog/." /opt/vpn-bot/module-catalog/
chown -R root:root /opt/vpn-bot/module-catalog
find /opt/vpn-bot/module-catalog -type d -exec chmod 0750 {} +
find /opt/vpn-bot/module-catalog -type f -exec chmod 0640 {} +
python3 "$MODULE_DIR/patch-bot-loader.py" /opt/vpn-bot/bot.py
/usr/local/sbin/vpn-bot-module install client-lifecycle
/usr/local/sbin/vpn-bot-module install as-network-guard
/usr/local/sbin/vpn-bot-module install admin-management

say "Готово"
echo "Список CyberOK сохранён в /etc/cyberok_ips.txt. При недоступности источника обновление использует этот кэш."
echo "После установки откройте Telegram-бота и отправьте команду /start с кодом, показанным установщиком Amnezia Server Kit выше."
echo "Функции бота: управление доступом в меню «Клиенты»; фильтр C24Be доступен в разделе «Состояние» и изначально выключен."
echo "Управление администраторами доступно кнопкой «Администраторы» в главном меню бота."
echo "Сетевую фильтрацию можно включить после загрузки списков кнопками Telegram-бота. Модулями управляет vpn-bot-module."
echo "Проверка: systemctl status vpn-bot.service tspublock-cyberok.service tspublock-cyberok.timer"
